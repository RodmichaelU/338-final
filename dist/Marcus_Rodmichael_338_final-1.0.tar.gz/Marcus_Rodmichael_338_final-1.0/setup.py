from setuptools import setup, find_packages

setup(name = 'Marcus_Rodmichael_338_final',
      version = '1.0',
      description = 'Package containing Linear, nodes and trees',
      author = 'Rodmichael',
      author_email= 'rodmichael.umapas@ucalgary.ca',
      packages = find_packages(),
      include_packages_data = True,
      install_require = [
            'numpy',
            'scipy'
      ],
)