from myLib.datastructures.nodes import TNode
from BST import BST