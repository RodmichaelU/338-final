from setuptools import setup, find_packages

setup(name = 'myLib_Marcus_Rodmichael',
      version = '1.0',
      description = 'Package containing Linear, nodes and trees',
      author = 'Rodmichael',
      author_email= 'rjumapas@shaw.ca',
      packages = find_packages(),
      include_packages_data = True,
      install_require = [
            'numpy',
            'scipy'
      ],
)